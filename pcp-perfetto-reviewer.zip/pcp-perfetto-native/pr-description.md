## Summary

Interleave CP all-gathers already produce equal physical rank blocks, including padded ragged batches. Reuse the existing `interleave_rows(..., output_rows=total_tokens)` copy for those batches instead of building an index tensor with arange/remainder/multiply/divide/add and performing an indexed copy. Retain the explicit gather-index path and the CPU/1D fallback.

## Validation

- H200: 27 isolated reorder cases; exact output equality.
- Eight-rank NCCL: 15 ragged shape cases in eager mode and 15 under CUDA graph replay, including 1D and higher-dimensional inputs; exact outputs and unchanged inputs.
- GLM-5.3-Flash, TP8/PCP8 interleave/DCP1/MTP3: two same-process ABBA runs, 168 measured requests each. Paired generated token IDs agree in all timing cases. Prefix-cache and mixed-length cases also pass. Fixed-input logprob differences are within baseline self-repeat variation.
- Bounded nsys, 1025 input tokens / 1 output token: 2586 → 2451 GPU kernels per rank (-135); NCCL count remains 187. Reorder uses 27 additional existing interleave copies and removes the corresponding index-building operations.
- End-to-end latency improvement is small and noisy; no broad percentage speedup is claimed.

The PR changes one framework file (+11/-21); it adds no kernel or benchmark instrumentation.

## Perfetto evidence

Fresh SGLang native PyTorch-profiler captures on GLM-5.3-Flash, 8 × H200,
TP8 / PCP8 interleave / DCP1 / MTP3, using automatically selected BF16 KV and
attention backends. Each full request uses 1,025 input tokens and 1 output token.
Both arms are warmed, then selected with acknowledgements on all eight ranks
in a same-process ABBA sequence. A second ABBA collection includes Python stacks.
All eight profiled responses have identical output token IDs; every rank hits
the changed ragged branch 27 times per request.

**Each reorder uses 6 → 1 GPU kernels; the full request uses 2,586 → 2,451
kernels per GPU, with 187 NCCL kernels unchanged.** These counts repeat on all
ranks in both collections. The CPU hierarchy shows the removed
`arange/remainder/mul/floor_divide/add/index_select` operations and the remaining
allocation plus launch of the existing `interleave_rows` kernel.

Attach `pcp-gather-comparison.png` and `pcp-perfetto-reviewer.zip`. The ZIP has
four full native rank-0 ABBA traces, actual Perfetto screenshots, and a
`review.html` entry point. The separate `pcp-perfetto-native.zip` contains all
64 rank traces, including the collection with Python stacks. No trace is cropped,
converted from nsys, or timestamp-adjusted. CPU operators, tensor shapes and
GPU events are retained. Search for `CP.gather.restore_token_order` in Perfetto.

Official Perfetto v59.1 ingestion reconciles CPU-op, GPU-kernel and Python-function
counts exactly for all eight rank-0 traces. Native overlap/spill diagnostics are
recorded in the validation report and explained in the README; raw files are
preserved unchanged. The screenshot arranges CPU regions from two actual UI
views with independent zoom. Profiled durations include instrumentation overhead
and are not an E2E speedup claim.
