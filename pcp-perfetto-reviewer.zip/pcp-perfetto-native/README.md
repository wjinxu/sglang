# Fresh SGLang native PyTorch profiler: PCP gather

GLM-5.3-Flash, 8 × H200, TP8 / PCP8 interleave / DCP1 / MTP3.
KV dtype and DSA backends are automatically selected; see the captured server info.
1025 input tokens, 1 output token, deterministic sampling. Warm both arms first,
then capture baseline/candidate/candidate/baseline in one model process.
Every capture includes all eight TP ranks, CPU + GPU and tensor shapes.
The additional with-stacks/ collection also includes Python call stacks.
The small reviewer ZIP contains four complete rank-0 ABBA traces and screenshots;
the full ZIP contains all 64 rank traces, including the with-stacks/ collection.
All four responses have identical output token IDs and every rank records hits
in the changed ragged branch. See capture.json for function hashes and counters.
Production commit: `8a67df6`.

## Open and navigate

Open `review.html` and choose Before or After. Alternatively drag a full
`.trace.json.gz` directly into https://ui.perfetto.dev.
The two primary files are `00-baseline-rank0.trace.json.gz` and `01-candidate-rank0.trace.json.gz`.
Click **Expand all**, search for **CP.gather.restore_token_order**, press Enter
or click the right search arrow after results appear, then blur the search box
and focus a matching slice with **F**. Its parent is
**CP._gather_interleaved_tensor [baseline/candidate]**.
The outer range includes the unchanged collective. The inner range covers only
restoring token order after the collective. Expand CPU operators and follow
CPU-to-GPU flow arrows to inspect corresponding kernels.

Before: arange/remainder/multiply/divide/add and index_select.
After: the existing interleave_rows copy trims padding while restoring order.
No new production kernel was added. Tensor shapes are visible in operator args.
The full request, other CPU operators and all GPU work remain in every raw file.

## Fresh measured counts (rank 0)

| ABBA slot | Arm | Full trace kernels | NCCL kernels | Reorder calls | Kernels linked to reorder |
|---|---|---|---|---|---|
| 0 | baseline | 2586 | 187 | 27 | 162 |
| 1 | candidate | 2451 | 187 | 27 | 27 |
| 2 | candidate | 2451 | 187 | 27 | 27 |
| 3 | baseline | 2586 | 187 | 27 | 162 |

Native profiler instrumentation adds overhead; these counts and scopes explain
the mechanism, and their durations are not an unprofiled E2E speedup estimate.
Independent prior ABBA latency measurements showed small, variable E2E gains.

## Provenance

These files were freshly recorded through SGLang `/start_profile` and
`/stop_profile`, activities CPU/GPU, record_shapes=true,
merge_profiles=false. The reviewer traces use with_stack=false to expose the
CPU operator hierarchy without verbose Python frames; the with-stacks/ folder
contains an additional full ABBA capture with with_stack=true. Both collections
retain complete CPU operators, shapes and GPU events. No nsys conversion,
slicing or timestamp rewriting was used. All 64 files are byte-identical copies
of the native outputs; hashes and
original paths are in manifest.json. Named record_function ranges were added
only by the experiment overlay, identically in both arms; production code is
unchanged by profiling. Capture records include live parameters and acknowledged
same-process A/B branch counters on all eight ranks.

Official Perfetto v59.1 imports all rank-0 ABBA traces from both collections.
Imported CPU-op, GPU-kernel and Python-function counts exactly match each raw
file. Perfetto reports `slice_spill_overlapping_complete_event` diagnostics for
overlapping native complete events (118–145 in the operator-focused collection,
180–383 with stacks). These diagnostics are recorded in perfetto-validation.json;
the files are unmodified and the reconciled events remain present. CPU and GPU
annotations each contain 27 matching ranges, so an unfiltered search shows 54
hits. GPU work is asynchronous: use launch flows or the matching GPU annotation
to find the kernel if it executes after the CPU range.

## Resolved capture configuration

BF16 KV; DSA prefill flashmla_sparse; DSA decode fa3; TP8 / PCP8 interleave / DCP1. Prefill CUDA graphs were disabled; decode graphs remained enabled. See run-config.json and capture-summary.json for the resolved settings and acknowledged branch hits. These files were added for PR review; native trace bytes are unchanged.
