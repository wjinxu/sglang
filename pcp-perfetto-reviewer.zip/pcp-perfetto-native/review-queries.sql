-- Full request counts. CPU/GPU annotations share names; filter by category.
SELECT category, count(*) AS n FROM slice GROUP BY category;

-- CPU operator hierarchy beneath all 27 reorder scopes.
SELECT op.name, count(*) AS n
FROM slice scope JOIN slice op ON op.track_id=scope.track_id
 AND op.ts>=scope.ts AND op.ts+op.dur<=scope.ts+scope.dur
WHERE scope.name='CP.gather.restore_token_order'
 AND scope.category='user_annotation' AND op.category='cpu_op'
GROUP BY op.name ORDER BY op.name;

-- Native complete-event overlap diagnostics; counts reconcile to raw JSON.
SELECT name,value FROM stats WHERE severity='error' AND value>0;
